package checkstudent.crypto;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Utilitaire de hachage de mots de passe.
 *
 * Algorithme : SHA-256 avec sel aléatoire (16 bytes)
 * Format stocké : Base64(salt) + ":" + Base64(hash)
 *
 * Note : En production, préférer BCrypt ou Argon2id
 * qui sont résistants aux attaques par force brute.
 */
public class PasswordHasher {

    private static final int SALT_SIZE = 16; // 128 bits

    /**
     * Génère un sel aléatoire.
     */
    public static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_SIZE];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    /**
     * Hache un mot de passe avec SHA-256 + sel.
     * @param password Mot de passe en clair
     * @param salt     Sel encodé en Base64
     * @return Hash encodé en Base64
     */
    public static String hash(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            // Applique le sel : hash(sel + password)
            byte[] saltBytes = Base64.getDecoder().decode(salt);
            digest.update(saltBytes);
            byte[] hashBytes = digest.digest(password.getBytes("UTF-8"));

            return Base64.getEncoder().encodeToString(hashBytes);
        } catch (Exception e) {
            throw new RuntimeException("Erreur hachage mot de passe : " + e.getMessage());
        }
    }

    /**
     * Vérifie un mot de passe contre son hash.
     * @param password      Mot de passe à vérifier
     * @param salt          Sel utilisé lors du hachage
     * @param expectedHash  Hash attendu
     * @return true si le mot de passe correspond
     */
    public static boolean verify(String password, String salt, String expectedHash) {
        String computed = hash(password, salt);
        // Comparaison en temps constant pour éviter les timing attacks
        return MessageDigest.isEqual(
            Base64.getDecoder().decode(computed),
            Base64.getDecoder().decode(expectedHash)
        );
    }
}
