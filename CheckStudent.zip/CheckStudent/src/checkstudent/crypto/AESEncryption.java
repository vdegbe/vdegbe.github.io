package checkstudent.crypto;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Utilitaire de chiffrement AES-256-GCM.
 *
 * AES-256 en mode GCM (Galois/Counter Mode) :
 *  - Confidentialité + intégrité (AEAD)
 *  - IV (nonce) aléatoire de 12 bytes généré à chaque chiffrement
 *  - Tag d'authentification de 128 bits
 *
 * Format du texte chiffré : Base64(IV || CipherText)
 */
public class AESEncryption {

    private static final String ALGORITHM  = "AES/GCM/NoPadding";
    private static final int    KEY_SIZE   = 256;
    private static final int    IV_SIZE    = 12;   // 96 bits — recommandé pour GCM
    private static final int    TAG_SIZE   = 128;  // bits

    // Clé AES-256 (en production : stocker dans un KeyStore sécurisé)
    private static final byte[] SECRET_KEY = "CheckStudent2025SecureKey!HETIC!!".getBytes();

    private static SecretKey getKey() {
        // Utilise les 32 premiers bytes (256 bits)
        byte[] keyBytes = new byte[32];
        System.arraycopy(SECRET_KEY, 0, keyBytes, 0, Math.min(SECRET_KEY.length, 32));
        return new SecretKeySpec(keyBytes, "AES");
    }

    /**
     * Chiffre une chaîne avec AES-256-GCM.
     * @param plainText Texte en clair
     * @return Texte chiffré encodé en Base64 (IV + ciphertext)
     */
    public static String encrypt(String plainText) throws Exception {
        SecureRandom random = new SecureRandom();
        byte[] iv = new byte[IV_SIZE];
        random.nextBytes(iv);

        Cipher cipher = Cipher.getInstance(ALGORITHM);
        GCMParameterSpec paramSpec = new GCMParameterSpec(TAG_SIZE, iv);
        cipher.init(Cipher.ENCRYPT_MODE, getKey(), paramSpec);

        byte[] cipherText = cipher.doFinal(plainText.getBytes("UTF-8"));

        // Concatène IV + cipherText
        byte[] combined = new byte[IV_SIZE + cipherText.length];
        System.arraycopy(iv, 0, combined, 0, IV_SIZE);
        System.arraycopy(cipherText, 0, combined, IV_SIZE, cipherText.length);

        return Base64.getEncoder().encodeToString(combined);
    }

    /**
     * Déchiffre une chaîne AES-256-GCM.
     * @param encryptedText Texte chiffré en Base64
     * @return Texte en clair
     */
    public static String decrypt(String encryptedText) throws Exception {
        byte[] combined = Base64.getDecoder().decode(encryptedText);

        // Extrait IV et cipherText
        byte[] iv         = new byte[IV_SIZE];
        byte[] cipherText = new byte[combined.length - IV_SIZE];
        System.arraycopy(combined, 0, iv, 0, IV_SIZE);
        System.arraycopy(combined, IV_SIZE, cipherText, 0, cipherText.length);

        Cipher cipher = Cipher.getInstance(ALGORITHM);
        GCMParameterSpec paramSpec = new GCMParameterSpec(TAG_SIZE, iv);
        cipher.init(Cipher.DECRYPT_MODE, getKey(), paramSpec);

        byte[] plainText = cipher.doFinal(cipherText);
        return new String(plainText, "UTF-8");
    }

    /**
     * Teste le chiffrement/déchiffrement.
     */
    public static void main(String[] args) throws Exception {
        String original  = "etudiant@hetic.net";
        String encrypted = encrypt(original);
        String decrypted = decrypt(encrypted);

        System.out.println("Original  : " + original);
        System.out.println("Chiffré   : " + encrypted);
        System.out.println("Déchiffré : " + decrypted);
        System.out.println("OK : " + original.equals(decrypted));
    }
}
