package checkstudent;

import checkstudent.ui.ConsoleUI;

/**
 * ╔══════════════════════════════════════════════════════╗
 * ║         CHECK STUDENT — Application Java            ║
 * ║         Vérification d'identité étudiante           ║
 * ║         Auteur : Vincent Degbe                      ║
 * ║         vdegbe.github.io                            ║
 * ╚══════════════════════════════════════════════════════╝
 *
 * Fonctionnalités :
 *  - Authentification sécurisée (hash SHA-256 + sel)
 *  - Contrôle d'accès RBAC (ADMIN, AGENT, ETUDIANT)
 *  - Chiffrement AES-256 des données sensibles
 *  - Vérification d'identité étudiante par carte/numéro
 *  - Journal d'audit des accès
 */
public class Main {
    public static void main(String[] args) {
        ConsoleUI ui = new ConsoleUI();
        ui.start();
    }
}
