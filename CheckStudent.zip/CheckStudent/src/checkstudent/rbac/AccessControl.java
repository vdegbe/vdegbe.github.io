package checkstudent.rbac;

import checkstudent.model.User.Role;

/**
 * Contrôle d'accès basé sur les rôles (RBAC).
 *
 * Matrice des permissions :
 * ┌─────────────────────────────────┬───────┬───────┬──────────┐
 * │ Permission                      │ ADMIN │ AGENT │ ETUDIANT │
 * ├─────────────────────────────────┼───────┼───────┼──────────┤
 * │ Vérifier identité               │  ✓    │  ✓    │          │
 * │ Voir données non sensibles      │  ✓    │  ✓    │  ✓ (soi) │
 * │ Voir données sensibles          │  ✓    │       │          │
 * │ Ajouter étudiant                │  ✓    │       │          │
 * │ Désactiver étudiant             │  ✓    │       │          │
 * │ Gérer utilisateurs              │  ✓    │       │          │
 * │ Consulter journal d'audit       │  ✓    │       │          │
 * └─────────────────────────────────┴───────┴───────┴──────────┘
 */
public class AccessControl {

    public enum Permission {
        VERIFY_IDENTITY,
        VIEW_BASIC_DATA,
        VIEW_SENSITIVE_DATA,
        ADD_STUDENT,
        DEACTIVATE_STUDENT,
        MANAGE_USERS,
        VIEW_AUDIT_LOG
    }

    /**
     * Vérifie si un rôle possède une permission.
     * @param role       Rôle de l'utilisateur
     * @param permission Permission demandée
     * @return true si autorisé
     */
    public static boolean hasPermission(Role role, Permission permission) {
        switch (role) {
            case ADMIN:
                return true; // Accès total

            case AGENT:
                return permission == Permission.VERIFY_IDENTITY
                    || permission == Permission.VIEW_BASIC_DATA;

            case ETUDIANT:
                return permission == Permission.VIEW_BASIC_DATA;

            default:
                return false;
        }
    }

    /**
     * Lève une exception si la permission est refusée.
     */
    public static void requirePermission(Role role, Permission permission)
            throws AccessDeniedException {
        if (!hasPermission(role, permission)) {
            throw new AccessDeniedException(
                String.format("Accès refusé : le rôle %s ne peut pas effectuer '%s'",
                              role, permission)
            );
        }
    }

    /**
     * Exception levée lors d'un refus d'accès.
     */
    public static class AccessDeniedException extends Exception {
        public AccessDeniedException(String message) {
            super(message);
        }
    }
}
