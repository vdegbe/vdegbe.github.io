package checkstudent.auth;

import checkstudent.model.Student;
import checkstudent.rbac.AccessControl;
import checkstudent.rbac.AccessControl.Permission;
import checkstudent.rbac.AccessControl.AccessDeniedException;
import checkstudent.model.User.Role;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service de gestion des étudiants.
 * Chaque opération vérifie les permissions RBAC avant d'accéder aux données.
 */
public class StudentService {

    private Map<String, Student> students = new HashMap<>();

    public StudentService() {
        loadSampleData();
    }

    /** Charge des données de démonstration */
    private void loadSampleData() {
        addStudentInternal("20240001", "Alice",   "MARTIN",   "alice.martin@hetic.net",   "15/03/2001", "Cybersécurité",   3);
        addStudentInternal("20240002", "Bob",     "DUPONT",   "bob.dupont@hetic.net",     "22/07/2000", "Réseaux",         4);
        addStudentInternal("20240003", "Chloé",   "BERNARD",  "chloe.bernard@hetic.net",  "08/11/2002", "Développement",   2);
        addStudentInternal("20240004", "David",   "LEROY",    "david.leroy@hetic.net",    "30/05/1999", "Cybersécurité",   5);
        addStudentInternal("20240005", "Emma",    "MOREAU",   "emma.moreau@hetic.net",    "14/09/2003", "Cloud & DevOps",  1);
    }

    private void addStudentInternal(String id, String first, String last,
                                     String email, String dob, String formation, int annee) {
        students.put(id, new Student(id, first, last, email, dob, formation, annee));
    }

    /**
     * Recherche un étudiant par numéro — nécessite VERIFY_IDENTITY.
     */
    public Student findById(String id, Role role) throws AccessDeniedException {
        AccessControl.requirePermission(role, Permission.VERIFY_IDENTITY);
        return students.get(id);
    }

    /**
     * Recherche par nom — nécessite VERIFY_IDENTITY.
     */
    public List<Student> findByName(String lastName, Role role) throws AccessDeniedException {
        AccessControl.requirePermission(role, Permission.VERIFY_IDENTITY);
        List<Student> result = new ArrayList<>();
        for (Student s : students.values()) {
            if (s.getLastName().equalsIgnoreCase(lastName)) {
                result.add(s);
            }
        }
        return result;
    }

    /**
     * Ajoute un étudiant — nécessite ADD_STUDENT (ADMIN uniquement).
     */
    public void addStudent(String id, String first, String last, String email,
                           String dob, String formation, int annee, Role role)
            throws AccessDeniedException {
        AccessControl.requirePermission(role, Permission.ADD_STUDENT);
        if (students.containsKey(id)) {
            throw new IllegalArgumentException("L'étudiant " + id + " existe déjà.");
        }
        addStudentInternal(id, first, last, email, dob, formation, annee);
    }

    /**
     * Désactive un étudiant — nécessite DEACTIVATE_STUDENT (ADMIN uniquement).
     */
    public void deactivateStudent(String id, Role role) throws AccessDeniedException {
        AccessControl.requirePermission(role, Permission.DEACTIVATE_STUDENT);
        Student s = students.get(id);
        if (s == null) throw new IllegalArgumentException("Étudiant " + id + " introuvable.");
        s.setActif(false);
    }

    /**
     * Liste tous les étudiants — nécessite VIEW_BASIC_DATA.
     */
    public List<Student> listAll(Role role) throws AccessDeniedException {
        AccessControl.requirePermission(role, Permission.VIEW_BASIC_DATA);
        return new ArrayList<>(students.values());
    }

    public int count() { return students.size(); }
}
