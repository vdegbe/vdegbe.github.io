package checkstudent.auth;

import checkstudent.crypto.PasswordHasher;
import checkstudent.model.User;
import checkstudent.model.User.Role;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service d'authentification.
 *
 * Sécurités implémentées :
 *  - Mots de passe hashés SHA-256 + sel
 *  - Verrouillage après 3 tentatives échouées
 *  - Journal d'audit de chaque tentative
 *  - Session avec token simple
 */
public class AuthService {

    private Map<String, User> users = new HashMap<>();
    private List<String> auditLog   = new ArrayList<>();
    private User currentUser        = null;

    public AuthService() {
        initDefaultUsers();
    }

    /** Initialise les utilisateurs par défaut */
    private void initDefaultUsers() {
        // Création des comptes de démo
        createUser("admin",    "Admin2025!",  Role.ADMIN);
        createUser("agent01",  "Agent2025!",  Role.AGENT);
        createUser("etudiant", "Etudiant123", Role.ETUDIANT);
    }

    /** Crée un nouvel utilisateur */
    public void createUser(String username, String password, Role role) {
        String salt = PasswordHasher.generateSalt();
        String hash = PasswordHasher.hash(password, salt);
        users.put(username, new User(username, hash, salt, role));
    }

    /**
     * Authentifie un utilisateur.
     * @return true si succès
     */
    public boolean login(String username, String password) {
        String timestamp = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        User user = users.get(username);

        if (user == null) {
            log(timestamp + " | ECHEC LOGIN | Utilisateur inconnu : " + username);
            return false;
        }

        if (user.isLocked()) {
            log(timestamp + " | COMPTE VERROUILLÉ | " + username);
            System.out.println("\n  [!] Compte verrouillé après 3 tentatives. Contactez l'administrateur.");
            return false;
        }

        if (!user.isActif()) {
            log(timestamp + " | COMPTE INACTIF | " + username);
            return false;
        }

        boolean valid = PasswordHasher.verify(password, user.getSalt(), user.getPasswordHash());

        if (valid) {
            user.resetFailedAttempts();
            currentUser = user;
            log(timestamp + " | SUCCÈS LOGIN | " + username + " | Rôle : " + user.getRole());
            return true;
        } else {
            user.incrementFailedAttempts();
            log(timestamp + " | ECHEC LOGIN | " + username
                + " | Tentatives : " + user.getFailedAttempts() + "/3");
            if (user.isLocked()) {
                log(timestamp + " | COMPTE VERROUILLÉ AUTOMATIQUEMENT | " + username);
            }
            return false;
        }
    }

    /** Déconnecte l'utilisateur courant */
    public void logout() {
        if (currentUser != null) {
            String timestamp = LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            log(timestamp + " | LOGOUT | " + currentUser.getUsername());
            currentUser = null;
        }
    }

    public User getCurrentUser() { return currentUser; }
    public boolean isLoggedIn()  { return currentUser != null; }

    private void log(String entry) {
        auditLog.add(entry);
    }

    public List<String> getAuditLog() {
        return new ArrayList<>(auditLog);
    }

    public Map<String, User> getUsers() {
        return users;
    }
}
