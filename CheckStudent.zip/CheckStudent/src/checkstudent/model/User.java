package checkstudent.model;

/**
 * Représente un utilisateur du système avec son rôle RBAC.
 */
public class User {

    public enum Role {
        ADMIN,    // Accès total : gestion utilisateurs, audit complet
        AGENT,    // Vérification identité, consultation données non sensibles
        ETUDIANT  // Consultation de ses propres données uniquement
    }

    private String username;
    private String passwordHash;  // SHA-256 + sel
    private String salt;
    private Role   role;
    private boolean actif;
    private int failedAttempts;
    private boolean locked;

    public User(String username, String passwordHash, String salt, Role role) {
        this.username       = username;
        this.passwordHash   = passwordHash;
        this.salt           = salt;
        this.role           = role;
        this.actif          = true;
        this.failedAttempts = 0;
        this.locked         = false;
    }

    // ── Getters / Setters ──
    public String  getUsername()      { return username; }
    public String  getPasswordHash()  { return passwordHash; }
    public String  getSalt()          { return salt; }
    public Role    getRole()          { return role; }
    public boolean isActif()          { return actif; }
    public boolean isLocked()         { return locked; }
    public int     getFailedAttempts(){ return failedAttempts; }

    public void incrementFailedAttempts() {
        this.failedAttempts++;
        if (this.failedAttempts >= 3) {
            this.locked = true;
        }
    }

    public void resetFailedAttempts() {
        this.failedAttempts = 0;
        this.locked = false;
    }

    public void setActif(boolean actif) { this.actif = actif; }

    @Override
    public String toString() {
        return String.format("User[%s | Role: %s | %s%s]",
                username, role,
                actif  ? "ACTIF" : "INACTIF",
                locked ? " | VERROUILLÉ" : "");
    }
}
