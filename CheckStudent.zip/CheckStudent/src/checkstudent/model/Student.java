package checkstudent.model;

import checkstudent.crypto.AESEncryption;
import java.time.LocalDate;

/**
 * Modèle représentant un étudiant.
 * Les données sensibles (email, date de naissance) sont chiffrées en AES-256.
 */
public class Student {

    private String id;               // Numéro étudiant (ex: 20240001)
    private String firstName;
    private String lastName;
    private String encryptedEmail;   // Email chiffré AES-256
    private String encryptedDOB;     // Date de naissance chiffrée
    private String formation;
    private int annee;               // Année d'étude (1-5)
    private boolean actif;           // Inscription active ou non

    public Student(String id, String firstName, String lastName,
                   String email, String dob, String formation, int annee) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.formation = formation;
        this.annee = annee;
        this.actif = true;

        // Chiffrement des données sensibles
        try {
            this.encryptedEmail = AESEncryption.encrypt(email);
            this.encryptedDOB   = AESEncryption.encrypt(dob);
        } catch (Exception e) {
            throw new RuntimeException("Erreur chiffrement données étudiant : " + e.getMessage());
        }
    }

    // ── Getters ──
    public String getId()        { return id; }
    public String getFirstName() { return firstName; }
    public String getLastName()  { return lastName; }
    public String getFormation() { return formation; }
    public int    getAnnee()     { return annee; }
    public boolean isActif()     { return actif; }

    /** Retourne le nom complet */
    public String getFullName() {
        return firstName + " " + lastName.toUpperCase();
    }

    /** Déchiffre et retourne l'email (accès contrôlé) */
    public String getEmail() {
        try {
            return AESEncryption.decrypt(encryptedEmail);
        } catch (Exception e) {
            return "[ERREUR DÉCHIFFREMENT]";
        }
    }

    /** Déchiffre et retourne la date de naissance (accès contrôlé) */
    public String getDateOfBirth() {
        try {
            return AESEncryption.decrypt(encryptedDOB);
        } catch (Exception e) {
            return "[ERREUR DÉCHIFFREMENT]";
        }
    }

    public void setActif(boolean actif) { this.actif = actif; }

    @Override
    public String toString() {
        return String.format("[%s] %s — %s — Année %d — %s",
                id, getFullName(), formation, annee, actif ? "ACTIF" : "INACTIF");
    }
}
