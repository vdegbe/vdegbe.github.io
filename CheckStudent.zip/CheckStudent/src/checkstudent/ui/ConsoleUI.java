package checkstudent.ui;

import checkstudent.auth.AuthService;
import checkstudent.auth.StudentService;
import checkstudent.model.Student;
import checkstudent.model.User;
import checkstudent.model.User.Role;
import checkstudent.rbac.AccessControl;
import checkstudent.rbac.AccessControl.Permission;
import checkstudent.rbac.AccessControl.AccessDeniedException;

import java.util.List;
import java.util.Scanner;

/**
 * Interface console de l'application Check Student.
 */
public class ConsoleUI {

    private AuthService    authService    = new AuthService();
    private StudentService studentService = new StudentService();
    private Scanner        scanner        = new Scanner(System.in);

    private static final String SEP =
        "══════════════════════════════════════════════════════";
    private static final String SEP_THIN =
        "──────────────────────────────────────────────────────";

    public void start() {
        printBanner();

        while (true) {
            if (!authService.isLoggedIn()) {
                showLoginMenu();
            } else {
                showMainMenu();
            }
        }
    }

    // ── BANNIÈRE ──
    private void printBanner() {
        System.out.println("\n" + SEP);
        System.out.println("  CHECK STUDENT — Vérification d'identité étudiante");
        System.out.println("  Auteur : Vincent Degbe | vdegbe.github.io");
        System.out.println("  Sécurité : AES-256-GCM + SHA-256 + RBAC");
        System.out.println(SEP);
        System.out.println("  Comptes de démo :");
        System.out.println("    admin    / Admin2025!   (ADMIN)");
        System.out.println("    agent01  / Agent2025!   (AGENT)");
        System.out.println("    etudiant / Etudiant123  (ETUDIANT)");
        System.out.println(SEP + "\n");
    }

    // ── LOGIN ──
    private void showLoginMenu() {
        System.out.println("  [ CONNEXION ]");
        System.out.print("  Identifiant : ");
        String username = scanner.nextLine().trim();
        System.out.print("  Mot de passe : ");
        String password = scanner.nextLine().trim();

        if (authService.login(username, password)) {
            User user = authService.getCurrentUser();
            System.out.println("\n  ✓ Connecté en tant que " + user.getUsername()
                    + " — Rôle : " + user.getRole() + "\n");
        } else {
            System.out.println("\n  ✗ Identifiants incorrects.\n");
        }
    }

    // ── MENU PRINCIPAL ──
    private void showMainMenu() {
        User user = authService.getCurrentUser();
        Role role = user.getRole();

        System.out.println(SEP);
        System.out.println("  Connecté : " + user.getUsername() + " [" + role + "]");
        System.out.println(SEP_THIN);
        System.out.println("  1. Vérifier un étudiant par numéro");
        System.out.println("  2. Rechercher un étudiant par nom");
        System.out.println("  3. Lister tous les étudiants");

        if (role == Role.ADMIN) {
            System.out.println("  4. Ajouter un étudiant");
            System.out.println("  5. Désactiver un étudiant");
            System.out.println("  6. Consulter le journal d'audit");
        }

        System.out.println("  0. Se déconnecter");
        System.out.println(SEP);
        System.out.print("  Choix : ");

        String choice = scanner.nextLine().trim();
        System.out.println();

        switch (choice) {
            case "1": verifyById(role);        break;
            case "2": searchByName(role);      break;
            case "3": listStudents(role);      break;
            case "4": if (role == Role.ADMIN) addStudent(role);        break;
            case "5": if (role == Role.ADMIN) deactivateStudent(role); break;
            case "6": if (role == Role.ADMIN) showAuditLog(role);      break;
            case "0": authService.logout(); System.out.println("  Déconnexion.\n"); break;
            default:  System.out.println("  Option invalide.\n");
        }
    }

    // ── VÉRIFIER PAR ID ──
    private void verifyById(Role role) {
        System.out.print("  Numéro étudiant : ");
        String id = scanner.nextLine().trim();
        try {
            Student s = studentService.findById(id, role);
            if (s == null) {
                System.out.println("  ✗ Aucun étudiant trouvé avec le numéro : " + id + "\n");
            } else {
                printStudent(s, role);
            }
        } catch (AccessDeniedException e) {
            System.out.println("  ✗ " + e.getMessage() + "\n");
        }
    }

    // ── RECHERCHE PAR NOM ──
    private void searchByName(Role role) {
        System.out.print("  Nom de famille : ");
        String name = scanner.nextLine().trim();
        try {
            List<Student> results = studentService.findByName(name, role);
            if (results.isEmpty()) {
                System.out.println("  Aucun résultat pour : " + name + "\n");
            } else {
                System.out.println("  " + results.size() + " résultat(s) :\n");
                for (Student s : results) printStudent(s, role);
            }
        } catch (AccessDeniedException e) {
            System.out.println("  ✗ " + e.getMessage() + "\n");
        }
    }

    // ── LISTE TOUS ──
    private void listStudents(Role role) {
        try {
            List<Student> all = studentService.listAll(role);
            System.out.println("  " + all.size() + " étudiant(s) enregistré(s) :\n");
            for (Student s : all) {
                System.out.println("  › " + s);
            }
            System.out.println();
        } catch (AccessDeniedException e) {
            System.out.println("  ✗ " + e.getMessage() + "\n");
        }
    }

    // ── AJOUTER ──
    private void addStudent(Role role) {
        System.out.println("  [ AJOUT ÉTUDIANT ]");
        System.out.print("  Numéro        : "); String id        = scanner.nextLine().trim();
        System.out.print("  Prénom        : "); String first     = scanner.nextLine().trim();
        System.out.print("  Nom           : "); String last      = scanner.nextLine().trim();
        System.out.print("  Email         : "); String email     = scanner.nextLine().trim();
        System.out.print("  Date naiss.   : "); String dob       = scanner.nextLine().trim();
        System.out.print("  Formation     : "); String formation = scanner.nextLine().trim();
        System.out.print("  Année (1-5)   : "); int    annee     = Integer.parseInt(scanner.nextLine().trim());

        try {
            studentService.addStudent(id, first, last, email, dob, formation, annee, role);
            System.out.println("  ✓ Étudiant ajouté avec succès.\n");
        } catch (AccessDeniedException | IllegalArgumentException e) {
            System.out.println("  ✗ " + e.getMessage() + "\n");
        }
    }

    // ── DÉSACTIVER ──
    private void deactivateStudent(Role role) {
        System.out.print("  Numéro étudiant à désactiver : ");
        String id = scanner.nextLine().trim();
        try {
            studentService.deactivateStudent(id, role);
            System.out.println("  ✓ Étudiant " + id + " désactivé.\n");
        } catch (AccessDeniedException | IllegalArgumentException e) {
            System.out.println("  ✗ " + e.getMessage() + "\n");
        }
    }

    // ── AUDIT LOG ──
    private void showAuditLog(Role role) {
        if (!AccessControl.hasPermission(role, Permission.VIEW_AUDIT_LOG)) {
            System.out.println("  ✗ Accès refusé.\n"); return;
        }
        System.out.println("  [ JOURNAL D'AUDIT ]\n");
        List<String> logs = authService.getAuditLog();
        if (logs.isEmpty()) {
            System.out.println("  Aucune entrée.\n");
        } else {
            for (String entry : logs) System.out.println("  " + entry);
            System.out.println();
        }
    }

    // ── AFFICHAGE ÉTUDIANT ──
    private void printStudent(Student s, Role role) {
        System.out.println("  " + SEP_THIN);
        System.out.println("  Numéro     : " + s.getId());
        System.out.println("  Nom        : " + s.getFullName());
        System.out.println("  Formation  : " + s.getFormation() + " — Année " + s.getAnnee());
        System.out.println("  Statut     : " + (s.isActif() ? "✓ ACTIF" : "✗ INACTIF"));

        // Données sensibles — ADMIN uniquement
        if (AccessControl.hasPermission(role, Permission.VIEW_SENSITIVE_DATA)) {
            System.out.println("  Email      : " + s.getEmail());
            System.out.println("  Naissance  : " + s.getDateOfBirth());
        }
        System.out.println("  " + SEP_THIN + "\n");
    }
}
