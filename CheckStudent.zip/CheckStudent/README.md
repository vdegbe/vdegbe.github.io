# Check Student — Vérification d'identité étudiante

> Projet Java démontrant la sécurisation d'une application avec chiffrement AES-256, hachage SHA-256 et contrôle d'accès RBAC.
> **Auteur : Vincent Degbe** — [vdegbe.github.io](https://vdegbe.github.io)

## Fonctionnalités

- **Authentification sécurisée** — SHA-256 + sel aléatoire, verrouillage après 3 tentatives
- **Chiffrement AES-256-GCM** — Données sensibles (email, date de naissance) chiffrées en base
- **Contrôle d'accès RBAC** — 3 rôles : ADMIN, AGENT, ETUDIANT
- **Vérification d'identité** — Recherche par numéro ou nom
- **Journal d'audit** — Toutes les tentatives de connexion tracées

## Architecture

```
src/checkstudent/
├── Main.java                    # Point d'entrée
├── model/
│   ├── Student.java             # Modèle étudiant (données chiffrées)
│   └── User.java                # Modèle utilisateur avec rôle
├── crypto/
│   ├── AESEncryption.java       # Chiffrement AES-256-GCM
│   └── PasswordHasher.java      # Hachage SHA-256 + sel
├── rbac/
│   └── AccessControl.java       # Matrice des permissions RBAC
├── auth/
│   ├── AuthService.java         # Authentification + audit log
│   └── StudentService.java      # Gestion étudiants (contrôle RBAC)
└── ui/
    └── ConsoleUI.java           # Interface console
```

## Matrice RBAC

| Permission             | ADMIN | AGENT | ETUDIANT |
|------------------------|-------|-------|----------|
| Vérifier identité      | ✓     | ✓     |          |
| Voir données de base   | ✓     | ✓     | ✓ (soi)  |
| Voir données sensibles | ✓     |       |          |
| Ajouter étudiant       | ✓     |       |          |
| Désactiver étudiant    | ✓     |       |          |
| Journal d'audit        | ✓     |       |          |

## Compilation & Exécution

```bash
# Compiler
javac -d out -sourcepath src src/checkstudent/Main.java

# Exécuter
java -cp out checkstudent.Main
```

## Comptes de démo

| Identifiant | Mot de passe | Rôle     |
|-------------|--------------|----------|
| admin       | Admin2025!   | ADMIN    |
| agent01     | Agent2025!   | AGENT    |
| etudiant    | Etudiant123  | ETUDIANT |

## Sécurité

- **AES-256-GCM** : chiffrement authentifié (confidentialité + intégrité)
- **IV aléatoire** : généré à chaque chiffrement (SecureRandom)
- **SHA-256 + sel** : résistance aux attaques par table arc-en-ciel
- **Timing-safe comparison** : `MessageDigest.isEqual()` contre les timing attacks
- **Verrouillage de compte** : après 3 tentatives échouées

---
*Vincent Degbe — Cybersécurité & Réseaux — [vdegbe.github.io](https://vdegbe.github.io)*
