# DAB — Distributeur Automatique de Billets (Java)

> Simulateur de guichet bancaire sécurisé en Java avec gestion des transactions, erreurs critiques et sécurité des sessions.
> **Auteur : Vincent Degbe** — [vdegbe.github.io](https://vdegbe.github.io)

## Fonctionnalités

- **Authentification carte + PIN** — SHA-256 + sel, verrouillage après 3 tentatives, carte avalée
- **Consultation de solde**
- **Retrait** — Vérification fonds, limite journalière (500€), multiples de 10€
- **Dépôt**
- **Virement** entre comptes
- **Historique des opérations**
- **Sécurité des sessions** — Timeout automatique après 60 secondes d'inactivité
- **Gestion des erreurs critiques** — Carte expirée, bloquée, avalée, fonds insuffisants

## Architecture

```
src/dab/
├── Main.java                    # Point d'entrée
├── model/
│   ├── Card.java                # Carte bancaire (statuts, PIN hashé)
│   └── Account.java             # Compte bancaire + transactions
├── security/
│   └── SessionManager.java      # Gestion session + timeout
├── service/
│   └── DABService.java          # Logique métier + exceptions
└── ui/
    └── ConsoleUI.java           # Interface console
```

## Compilation & Exécution

```bash
# Compiler
javac -d out -sourcepath src src/dab/Main.java

# Exécuter
java -cp out dab.Main
```

## Cartes de démo

| Numéro de carte      | PIN  | Titulaire     | Solde    |
|----------------------|------|---------------|----------|
| 4111111111111234     | 1234 | Alice MARTIN  | 2 500 €  |
| 4111111111115678     | 5678 | Bob DUPONT    | 800 €    |
| 4111111111110000     | 0000 | Claire LEROY  | 15 000 € |

## Sécurité implémentée

- **SHA-256 + sel** pour le PIN (résistance aux rainbow tables)
- **Timing-safe comparison** contre les timing attacks
- **Verrouillage automatique** après 3 tentatives PIN incorrectes
- **Carte avalée** en cas de fraude détectée
- **Session timeout** — 60 secondes d'inactivité
- **Validation des montants** — Multiples de 10€, limites journalières
- **Exceptions métier** — Gestion complète des cas d'erreur critiques

---
*Vincent Degbe — Cybersécurité & Réseaux — [vdegbe.github.io](https://vdegbe.github.io)*
