package dab.service;

import dab.model.Account;
import dab.model.Card;
import dab.model.Card.Status;
import dab.security.SessionManager;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * Service principal du DAB.
 * Gère l'authentification, les transactions et les erreurs critiques.
 */
public class DABService {

    // Exceptions métier
    public static class CardBlockedException    extends Exception { public CardBlockedException(String m)    { super(m); } }
    public static class CardExpiredException    extends Exception { public CardExpiredException(String m)    { super(m); } }
    public static class CardSwallowedException  extends Exception { public CardSwallowedException(String m)  { super(m); } }
    public static class InsufficientFundsException extends Exception { public InsufficientFundsException(String m) { super(m); } }
    public static class DailyLimitException     extends Exception { public DailyLimitException(String m)    { super(m); } }
    public static class InvalidAmountException  extends Exception { public InvalidAmountException(String m)  { super(m); } }
    public static class SessionExpiredException extends Exception { public SessionExpiredException(String m) { super(m); } }
    public static class AccountNotFoundException extends Exception { public AccountNotFoundException(String m){ super(m); } }

    private Map<String, Card>    cards    = new HashMap<>();
    private Map<String, Account> accounts = new HashMap<>();
    private SessionManager       session  = new SessionManager();
    private double               dabCash  = 10000.0; // Cash disponible dans le DAB

    public DABService() {
        loadDemoData();
    }

    // ── Données de démo ──
    private void loadDemoData() {
        // Créer comptes
        accounts.put("ACC001", new Account("ACC001", "Alice MARTIN",  2500.00, Account.Type.COURANT));
        accounts.put("ACC002", new Account("ACC002", "Bob DUPONT",    800.50,  Account.Type.COURANT));
        accounts.put("ACC003", new Account("ACC003", "Claire LEROY",  15000.0, Account.Type.EPARGNE));

        // Créer cartes (PIN hashé)
        // Alice : PIN 1234
        String salt1 = generateSalt();
        String hash1 = hashPin("1234", salt1);
        cards.put("4111111111111234", new Card("4111111111111234", hash1, salt1, "12/26", "Alice MARTIN", "ACC001"));

        // Bob : PIN 5678
        String salt2 = generateSalt();
        String hash2 = hashPin("5678", salt2);
        cards.put("4111111111115678", new Card("4111111111115678", hash2, salt2, "06/25", "Bob DUPONT", "ACC002"));

        // Claire : PIN 0000
        String salt3 = generateSalt();
        String hash3 = hashPin("0000", salt3);
        cards.put("4111111111110000", new Card("4111111111110000", hash3, salt3, "03/27", "Claire LEROY", "ACC003"));
    }

    // ── PIN hashing ──
    private String generateSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    private String hashPin(String pin, String salt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(Base64.getDecoder().decode(salt));
            return Base64.getEncoder().encodeToString(md.digest(pin.getBytes()));
        } catch (Exception e) {
            throw new RuntimeException("Erreur hachage PIN");
        }
    }

    private boolean verifyPin(String pin, String salt, String expectedHash) {
        String computed = hashPin(pin, salt);
        return MessageDigest.isEqual(
            Base64.getDecoder().decode(computed),
            Base64.getDecoder().decode(expectedHash)
        );
    }

    // ══════════════════════════════════════
    // AUTHENTIFICATION
    // ══════════════════════════════════════

    /**
     * Étape 1 : Insertion de la carte.
     */
    public Card insertCard(String cardNumber)
            throws CardBlockedException, CardExpiredException, CardSwallowedException {
        Card card = cards.get(cardNumber);
        if (card == null) throw new CardBlockedException("Carte inconnue.");

        if (card.getStatus() == Status.SWALLOWED)
            throw new CardSwallowedException("Carte avalée. Contactez votre banque.");
        if (card.getStatus() == Status.BLOCKED)
            throw new CardBlockedException("Carte bloquée. Contactez votre banque.");
        if (card.isExpired())
            throw new CardExpiredException("Carte expirée. Contactez votre banque.");

        return card;
    }

    /**
     * Étape 2 : Vérification du PIN.
     * @return true si PIN correct
     */
    public boolean verifyPin(Card card, String pin)
            throws CardSwallowedException {
        if (verifyPin(pin, card.getPinSalt(), card.getPinHash())) {
            card.resetFailedPin();
            Account account = accounts.get(card.getAccountId());
            session.openSession(card, account);
            return true;
        } else {
            card.incrementFailedPin();
            if (card.getStatus() == Status.SWALLOWED) {
                throw new CardSwallowedException(
                    "3 tentatives incorrectes — Carte avalée. Contactez votre banque.");
            }
            return false;
        }
    }

    // ══════════════════════════════════════
    // TRANSACTIONS
    // ══════════════════════════════════════

    /**
     * Consulte le solde.
     */
    public double getBalance() throws SessionExpiredException {
        checkSession();
        return session.getCurrentAccount().getBalance();
    }

    /**
     * Effectue un retrait.
     */
    public double withdraw(double amount)
            throws SessionExpiredException, InvalidAmountException,
                   InsufficientFundsException, DailyLimitException {
        checkSession();

        // Validations
        if (amount <= 0)
            throw new InvalidAmountException("Le montant doit être positif.");
        if (amount % 10 != 0)
            throw new InvalidAmountException("Le montant doit être un multiple de 10€.");
        if (amount > dabCash)
            throw new InvalidAmountException("Le DAB ne dispose pas de suffisamment de billets. Montant max : " + (int)dabCash + "€");

        Account account = session.getCurrentAccount();

        if (!account.hasSufficientFunds(amount))
            throw new InsufficientFundsException(
                String.format("Solde insuffisant. Solde disponible : %.2f €", account.getBalance()));

        if (!account.withinDailyLimit(amount))
            throw new DailyLimitException(
                String.format("Limite journalière dépassée. Restant : %.2f €",
                    account.getDailyLimit() - account.getWithdrawnToday()));

        account.withdraw(amount);
        dabCash -= amount;
        session.refreshActivity();
        return amount;
    }

    /**
     * Effectue un dépôt.
     */
    public void deposit(double amount)
            throws SessionExpiredException, InvalidAmountException {
        checkSession();
        if (amount <= 0)
            throw new InvalidAmountException("Le montant doit être positif.");
        session.getCurrentAccount().deposit(amount);
        dabCash += amount;
        session.refreshActivity();
    }

    /**
     * Effectue un virement.
     */
    public void transfer(String targetAccountId, double amount)
            throws SessionExpiredException, InvalidAmountException,
                   InsufficientFundsException, AccountNotFoundException {
        checkSession();

        if (amount <= 0)
            throw new InvalidAmountException("Le montant doit être positif.");

        Account source = session.getCurrentAccount();
        Account target = accounts.get(targetAccountId);

        if (target == null)
            throw new AccountNotFoundException("Compte destinataire introuvable : " + targetAccountId);
        if (source.getId().equals(targetAccountId))
            throw new InvalidAmountException("Impossible de virer vers le même compte.");
        if (!source.hasSufficientFunds(amount))
            throw new InsufficientFundsException(
                String.format("Solde insuffisant. Solde : %.2f €", source.getBalance()));

        source.transferOut(amount, targetAccountId);
        target.transferIn(amount, source.getId());
        session.refreshActivity();
    }

    /**
     * Retourne l'historique des transactions.
     */
    public java.util.List<Account.Transaction> getHistory() throws SessionExpiredException {
        checkSession();
        return session.getCurrentAccount().getTransactions();
    }

    /**
     * Termine la session (éjecte la carte).
     */
    public void endSession() {
        session.closeSession();
    }

    // ── Helpers ──
    private void checkSession() throws SessionExpiredException {
        if (!session.isActive() || !session.isSessionValid())
            throw new SessionExpiredException("Session expirée. Veuillez réinsérer votre carte.");
    }

    public SessionManager getSession() { return session; }
    public double getDabCash()         { return dabCash; }
}
