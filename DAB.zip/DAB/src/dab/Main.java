package dab;

import dab.ui.ConsoleUI;

/**
 * ╔══════════════════════════════════════════════════════╗
 * ║         DAB — Distributeur Automatique de Billets   ║
 * ║         Simulateur Java sécurisé                    ║
 * ║         Auteur : Vincent Degbe                      ║
 * ║         vdegbe.github.io                            ║
 * ╚══════════════════════════════════════════════════════╝
 *
 * Fonctionnalités :
 *  - Authentification par carte + code PIN (3 essais max)
 *  - Consultation de solde
 *  - Retrait avec vérification de fonds et limites journalières
 *  - Dépôt
 *  - Virement entre comptes
 *  - Gestion des erreurs critiques (carte avalée, session expirée)
 *  - Sécurité des sessions (timeout automatique)
 *  - Journal de transactions
 */
public class Main {
    public static void main(String[] args) {
        ConsoleUI ui = new ConsoleUI();
        ui.start();
    }
}
