package dab.ui;

import dab.model.Account;
import dab.model.Card;
import dab.service.DABService;
import dab.service.DABService.*;

import java.util.List;
import java.util.Scanner;

/**
 * Interface console du DAB.
 */
public class ConsoleUI {

    private DABService dab     = new DABService();
    private Scanner    scanner = new Scanner(System.in);

    private static final String SEP      = "══════════════════════════════════════════════";
    private static final String SEP_THIN = "──────────────────────────────────────────────";

    public void start() {
        printBanner();
        while (true) {
            runDABCycle();
        }
    }

    private void printBanner() {
        System.out.println("\n" + SEP);
        System.out.println("  ██████╗  █████╗ ██████╗ ");
        System.out.println("  ██╔══██╗██╔══██╗██╔══██╗");
        System.out.println("  ██║  ██║███████║██████╔╝");
        System.out.println("  ██║  ██║██╔══██║██╔══██╗");
        System.out.println("  ██████╔╝██║  ██║██████╔╝");
        System.out.println("  ╚═════╝ ╚═╝  ╚═╝╚═════╝ ");
        System.out.println("  Distributeur Automatique de Billets");
        System.out.println("  Auteur : Vincent Degbe | vdegbe.github.io");
        System.out.println(SEP);
        System.out.println("  Cartes de démo :");
        System.out.println("    4111111111111234  PIN: 1234  (Alice  — 2500€)");
        System.out.println("    4111111111115678  PIN: 5678  (Bob    — 800€)");
        System.out.println("    4111111111110000  PIN: 0000  (Claire — 15000€)");
        System.out.println(SEP + "\n");
    }

    // ── CYCLE PRINCIPAL ──
    private void runDABCycle() {
        // 1. Insertion carte
        System.out.println("  Veuillez insérer votre carte (numéro) ou 'quitter' :");
        System.out.print("  > ");
        String cardNumber = scanner.nextLine().trim();

        if (cardNumber.equalsIgnoreCase("quitter")) {
            System.out.println("\n  Au revoir.\n");
            System.exit(0);
        }

        Card card;
        try {
            card = dab.insertCard(cardNumber);
        } catch (CardSwallowedException e) {
            printError("CARTE AVALÉE", e.getMessage());
            return;
        } catch (CardExpiredException e) {
            printError("CARTE EXPIRÉE", e.getMessage());
            return;
        } catch (CardBlockedException e) {
            printError("CARTE BLOQUÉE", e.getMessage());
            return;
        }

        System.out.println("\n  Carte acceptée : " + card.getMaskedNumber());

        // 2. Vérification PIN
        boolean authenticated = false;
        while (!authenticated && card.getFailedPinAttempts() < 3) {
            int remaining = 3 - card.getFailedPinAttempts();
            System.out.print("  Code PIN (" + remaining + " essai(s) restant(s)) : ");
            String pin = scanner.nextLine().trim();

            try {
                if (dab.verifyPin(card, pin)) {
                    authenticated = true;
                    System.out.println("  ✓ Authentification réussie. Bonjour " + card.getOwnerName() + " !\n");
                } else {
                    System.out.println("  ✗ Code PIN incorrect.");
                }
            } catch (CardSwallowedException e) {
                printError("CARTE AVALÉE", e.getMessage());
                return;
            }
        }

        if (!authenticated) return;

        // 3. Menu principal
        mainMenu();

        // 4. Fin de session
        dab.endSession();
        System.out.println("\n  Carte restituée. Merci et au revoir.\n");
        System.out.println(SEP + "\n");
    }

    // ── MENU PRINCIPAL ──
    private void mainMenu() {
        while (true) {
            System.out.println(SEP);
            System.out.println("  QUE SOUHAITEZ-VOUS FAIRE ?");
            System.out.println(SEP_THIN);
            System.out.println("  1. Consulter mon solde");
            System.out.println("  2. Retirer de l'argent");
            System.out.println("  3. Déposer de l'argent");
            System.out.println("  4. Effectuer un virement");
            System.out.println("  5. Voir mes dernières opérations");
            System.out.println("  0. Fin de session (éjecter la carte)");
            System.out.println(SEP);
            System.out.print("  Votre choix : ");

            String choice = scanner.nextLine().trim();
            System.out.println();

            try {
                switch (choice) {
                    case "1": showBalance();   break;
                    case "2": doWithdraw();    break;
                    case "3": doDeposit();     break;
                    case "4": doTransfer();    break;
                    case "5": showHistory();   break;
                    case "0": return;
                    default:  System.out.println("  Option invalide.\n");
                }
            } catch (SessionExpiredException e) {
                printError("SESSION EXPIRÉE", e.getMessage());
                return;
            }
        }
    }

    // ── CONSULTATION SOLDE ──
    private void showBalance() throws SessionExpiredException {
        double balance = dab.getBalance();
        System.out.println(SEP_THIN);
        System.out.printf("  Solde disponible : %.2f €%n", balance);
        System.out.println(SEP_THIN + "\n");
    }

    // ── RETRAIT ──
    private void doWithdraw() throws SessionExpiredException {
        System.out.print("  Montant à retirer (multiple de 10€) : ");
        try {
            double amount = Double.parseDouble(scanner.nextLine().trim());
            double dispensed = dab.withdraw(amount);
            System.out.println(SEP_THIN);
            System.out.printf("  ✓ Veuillez récupérer vos billets : %.0f €%n", dispensed);
            System.out.println(SEP_THIN + "\n");
        } catch (NumberFormatException e) {
            System.out.println("  ✗ Montant invalide.\n");
        } catch (InvalidAmountException | InsufficientFundsException | DailyLimitException e) {
            printError("TRANSACTION REFUSÉE", e.getMessage());
        }
    }

    // ── DÉPÔT ──
    private void doDeposit() throws SessionExpiredException {
        System.out.print("  Montant à déposer : ");
        try {
            double amount = Double.parseDouble(scanner.nextLine().trim());
            dab.deposit(amount);
            System.out.println("  ✓ Dépôt de " + String.format("%.2f", amount) + " € effectué.\n");
        } catch (NumberFormatException e) {
            System.out.println("  ✗ Montant invalide.\n");
        } catch (InvalidAmountException e) {
            printError("TRANSACTION REFUSÉE", e.getMessage());
        }
    }

    // ── VIREMENT ──
    private void doTransfer() throws SessionExpiredException {
        System.out.print("  Numéro du compte destinataire : ");
        String targetId = scanner.nextLine().trim();
        System.out.print("  Montant du virement : ");
        try {
            double amount = Double.parseDouble(scanner.nextLine().trim());
            dab.transfer(targetId, amount);
            System.out.println("  ✓ Virement de " + String.format("%.2f", amount)
                    + " € vers " + targetId + " effectué.\n");
        } catch (NumberFormatException e) {
            System.out.println("  ✗ Montant invalide.\n");
        } catch (InvalidAmountException | InsufficientFundsException | AccountNotFoundException e) {
            printError("VIREMENT REFUSÉ", e.getMessage());
        }
    }

    // ── HISTORIQUE ──
    private void showHistory() throws SessionExpiredException {
        List<Account.Transaction> history = dab.getHistory();
        System.out.println(SEP_THIN);
        System.out.println("  HISTORIQUE DES OPÉRATIONS");
        System.out.println(SEP_THIN);
        if (history.isEmpty()) {
            System.out.println("  Aucune opération enregistrée.");
        } else {
            int start = Math.max(0, history.size() - 5); // 5 dernières
            for (int i = start; i < history.size(); i++) {
                System.out.println(history.get(i));
            }
        }
        System.out.println(SEP_THIN + "\n");
    }

    // ── Affichage erreur ──
    private void printError(String title, String message) {
        System.out.println("\n  ╔═ " + title + " ═╗");
        System.out.println("  ✗ " + message);
        System.out.println("  ╚" + "═".repeat(title.length() + 4) + "╝\n");
    }
}
