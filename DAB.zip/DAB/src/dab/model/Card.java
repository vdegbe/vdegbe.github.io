package dab.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Représente une carte bancaire.
 */
public class Card {

    public enum Status {
        ACTIVE,   // Carte valide
        BLOCKED,  // Bloquée après 3 PIN incorrects
        EXPIRED,  // Date d'expiration dépassée
        SWALLOWED // Carte avalée par le DAB
    }

    private String number;        // Numéro de carte (masqué à l'affichage)
    private String pinHash;       // Hash SHA-256 du code PIN
    private String pingSalt;
    private LocalDate expiryDate;
    private String ownerName;
    private String accountId;     // Compte associé
    private Status status;
    private int failedPinAttempts;

    public Card(String number, String pinHash, String pinSalt,
                String expiryDate, String ownerName, String accountId) {
        this.number            = number;
        this.pinHash           = pinHash;
        this.pingSalt          = pinSalt;
        this.expiryDate        = LocalDate.parse(expiryDate,
                                   DateTimeFormatter.ofPattern("MM/yy").withResolverStyle(
                                   java.time.format.ResolverStyle.LENIENT));
        this.ownerName         = ownerName;
        this.accountId         = accountId;
        this.status            = Status.ACTIVE;
        this.failedPinAttempts = 0;
    }

    public boolean isExpired() {
        return LocalDate.now().isAfter(expiryDate);
    }

    public boolean isUsable() {
        return status == Status.ACTIVE && !isExpired();
    }

    public void incrementFailedPin() {
        failedPinAttempts++;
        if (failedPinAttempts >= 3) {
            status = Status.SWALLOWED;
        }
    }

    public void resetFailedPin() { failedPinAttempts = 0; }

    /** Affiche le numéro masqué : **** **** **** 1234 */
    public String getMaskedNumber() {
        if (number.length() < 4) return "****";
        return "**** **** **** " + number.substring(number.length() - 4);
    }

    // Getters
    public String    getNumber()           { return number; }
    public String    getPinHash()          { return pinHash; }
    public String    getPinSalt()          { return pingSalt; }
    public String    getOwnerName()        { return ownerName; }
    public String    getAccountId()        { return accountId; }
    public Status    getStatus()           { return status; }
    public int       getFailedPinAttempts(){ return failedPinAttempts; }
    public void      setStatus(Status s)   { this.status = s; }
}
