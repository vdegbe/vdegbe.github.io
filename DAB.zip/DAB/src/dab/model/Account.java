package dab.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Représente un compte bancaire.
 */
public class Account {

    public enum Type { COURANT, EPARGNE }

    private String id;
    private String ownerName;
    private double balance;
    private Type   type;
    private boolean active;

    // Limites
    private double dailyWithdrawLimit;     // Limite journalière (défaut : 500€)
    private double withdrawnToday;         // Montant déjà retiré aujourd'hui
    private LocalDateTime lastWithdrawDay; // Dernier jour de retrait

    // Historique
    private List<Transaction> transactions = new ArrayList<>();

    public Account(String id, String ownerName, double balance, Type type) {
        this.id                = id;
        this.ownerName         = ownerName;
        this.balance           = balance;
        this.type              = type;
        this.active            = true;
        this.dailyWithdrawLimit = 500.0;
        this.withdrawnToday    = 0.0;
    }

    /** Solde disponible après vérification */
    public boolean hasSufficientFunds(double amount) {
        return balance >= amount;
    }

    /** Vérifie si le retrait respecte la limite journalière */
    public boolean withinDailyLimit(double amount) {
        resetDailyLimitIfNewDay();
        return (withdrawnToday + amount) <= dailyWithdrawLimit;
    }

    /** Effectue un retrait */
    public void withdraw(double amount) {
        resetDailyLimitIfNewDay();
        balance -= amount;
        withdrawnToday += amount;
        lastWithdrawDay = LocalDateTime.now();
        addTransaction("RETRAIT", -amount);
    }

    /** Effectue un dépôt */
    public void deposit(double amount) {
        balance += amount;
        addTransaction("DEPOT", +amount);
    }

    /** Effectue un virement sortant */
    public void transferOut(double amount, String targetId) {
        balance -= amount;
        addTransaction("VIREMENT VERS " + targetId, -amount);
    }

    /** Effectue un virement entrant */
    public void transferIn(double amount, String sourceId) {
        balance += amount;
        addTransaction("VIREMENT DE " + sourceId, +amount);
    }

    private void resetDailyLimitIfNewDay() {
        if (lastWithdrawDay == null ||
            !lastWithdrawDay.toLocalDate().equals(LocalDateTime.now().toLocalDate())) {
            withdrawnToday = 0.0;
        }
    }

    private void addTransaction(String type, double amount) {
        transactions.add(new Transaction(type, amount, balance));
    }

    // Getters
    public String  getId()           { return id; }
    public String  getOwnerName()    { return ownerName; }
    public double  getBalance()      { return balance; }
    public Type    getType()         { return type; }
    public boolean isActive()        { return active; }
    public double  getDailyLimit()   { return dailyWithdrawLimit; }
    public double  getWithdrawnToday(){ return withdrawnToday; }
    public List<Transaction> getTransactions() { return transactions; }

    public String getFormattedBalance() {
        return String.format("%.2f €", balance);
    }

    // ── Transaction interne ──
    public static class Transaction {
        private String type;
        private double amount;
        private double balanceAfter;
        private String timestamp;

        public Transaction(String type, double amount, double balanceAfter) {
            this.type         = type;
            this.amount       = amount;
            this.balanceAfter = balanceAfter;
            this.timestamp    = LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        }

        @Override
        public String toString() {
            String sign = amount >= 0 ? "+" : "";
            return String.format("  [%s] %-25s %s%.2f €  (Solde: %.2f €)",
                    timestamp, type, sign, amount, balanceAfter);
        }
    }
}
