package dab.security;

import dab.model.Card;
import dab.model.Account;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Gestionnaire de session sécurisée du DAB.
 *
 * Sécurités :
 *  - Timeout automatique après 60 secondes d'inactivité
 *  - Destruction des données sensibles à la fin de session
 *  - Verrouillage de carte après 3 PIN incorrects
 */
public class SessionManager {

    private static final int SESSION_TIMEOUT_SECONDS = 60;

    private Card          currentCard    = null;
    private Account       currentAccount = null;
    private LocalDateTime lastActivity   = null;
    private boolean       sessionActive  = false;

    /** Ouvre une session */
    public void openSession(Card card, Account account) {
        this.currentCard    = card;
        this.currentAccount = account;
        this.lastActivity   = LocalDateTime.now();
        this.sessionActive  = true;
    }

    /** Ferme et nettoie la session */
    public void closeSession() {
        currentCard    = null;
        currentAccount = null;
        lastActivity   = null;
        sessionActive  = false;
    }

    /** Vérifie si la session est encore valide (timeout) */
    public boolean isSessionValid() {
        if (!sessionActive || lastActivity == null) return false;

        long secondsElapsed = ChronoUnit.SECONDS.between(lastActivity, LocalDateTime.now());
        if (secondsElapsed > SESSION_TIMEOUT_SECONDS) {
            System.out.println("\n  [!] Session expirée après inactivité. Carte restituée.");
            closeSession();
            return false;
        }
        return true;
    }

    /** Met à jour le timestamp d'activité */
    public void refreshActivity() {
        if (sessionActive) lastActivity = LocalDateTime.now();
    }

    /** Retourne le temps restant en secondes */
    public long getRemainingSeconds() {
        if (!sessionActive || lastActivity == null) return 0;
        long elapsed = ChronoUnit.SECONDS.between(lastActivity, LocalDateTime.now());
        return Math.max(0, SESSION_TIMEOUT_SECONDS - elapsed);
    }

    public boolean      isActive()        { return sessionActive; }
    public Card         getCurrentCard()  { return currentCard; }
    public Account      getCurrentAccount(){ return currentAccount; }
}
